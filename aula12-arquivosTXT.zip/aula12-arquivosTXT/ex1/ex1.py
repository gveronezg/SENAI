arquivo = open('exercicio1.txt','w')

arquivo.close()