# Cria o arquivo exercicio1.txt quando não encontrado na pasta
arquivo = open('exercicio1.txt','w')
# Fecha o arquivo para concluir a operação
arquivo.close()