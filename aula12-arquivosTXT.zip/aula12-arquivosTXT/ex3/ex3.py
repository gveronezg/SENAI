arquivo = open('notas.txt','w')

i=1
while i<=3:
    arquivo.write(f'{i}º linha de texto\n')
    i+=1

arquivo.close()