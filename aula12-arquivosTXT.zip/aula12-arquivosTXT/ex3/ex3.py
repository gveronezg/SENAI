# Cria o arquivo notas.txt quando não encontrado na pasta
arquivo = open('notas.txt','w')
# Inicializa a variavel de loop
i=1
# Faz o loop até a 3º vez
while i<=3:
    # Escreve a linha de texto
    arquivo.write(f'{i}º linha de texto\n')
    # Incrementa a variavel de loop
    i+=1
# Fecha o arquivo para concluir a operação
arquivo.close()