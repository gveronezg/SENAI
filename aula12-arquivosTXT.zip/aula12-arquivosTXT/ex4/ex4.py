# Cria o arquivo numeros.txt quando não encontrado na pasta
arquivo = open('numeros.txt','w')
# Faz o loop 10 vezes
for x in range(1,11):
    # Escreve o numero em questão e pula linha
    arquivo.write(f'{x}\n')
# Fecha o arquivo para concluir a operação
arquivo.close()