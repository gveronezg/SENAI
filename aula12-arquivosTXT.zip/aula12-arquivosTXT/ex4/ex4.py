arquivo = open('notas.txt','w')

i=1
for x in range(1,11):
    arquivo.write(f'{x}\n')

arquivo.close()