arquivo = open('exercicio1.txt','w')

arquivo.write('Escrevendo algo para ser printado.')

arquivo.close()

leitura = open('exercicio1.txt','r')

print(leitura.read())

leitura.close()