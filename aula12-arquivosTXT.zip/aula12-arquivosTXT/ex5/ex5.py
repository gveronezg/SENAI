# Cria o arquivo numeros.txt quando não encontrado na pasta
arquivo = open('exercicio1.txt','w')
# Escreve algo para ser printado
arquivo.write('Escrevendo algo para ser printado.')
# Fecha o arquivo para concluir a operação
arquivo.close()
# Abre o arquino no modo leitura
leitura = open('exercicio1.txt','r')
# Printa o que foi lido no arquivo
print(leitura.read())
# Fecha o arquivo para concluir a operação
leitura.close()