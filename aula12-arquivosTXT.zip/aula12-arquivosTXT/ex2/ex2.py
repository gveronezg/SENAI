# Cria o arquivo mensagem.txt quando não encontrado na pasta
arquivo = open('mensagem.txt','w')
# Escreve este texto 'Estou aprendendo Python!' no arquivo
arquivo.write('Estou aprendendo Python!')
# Fecha o arquivo para concluir a operação
arquivo.close()