arquivo = open('mensagem.txt','w')

arquivo.write('Estou aprendendo Python!')

arquivo.close()