# SENAI

1º Aula - 22/07/2024 ###########################################################################################################

Algoritmo
	Sequência finita de passos que levam à execução de uma tarefa.
	Sequência de instruções para um fim específico.

Tripé do algoritmo
	Entrada de Dados
	Processamento
	Saída

Forma de apresentação:
	Descrição Narrativa
	Fluxograma
	Pseudocódigo

Algoritmo para realizar a troca de um pneu furado:
	1-Pegar o macaco e a chave de roda.
	2-Pegar o step.
	3-Levantar o carro com o macaco.
	4-Retirar a roda furada.
	5-Colocar o step.
	6-Abaixar o carro.
	7-Guardar a roda furada.
	8-Guardar o macaco e a chave de roda.

2º Aula - 23/07/2024 ###########################################################################################################

WI-FI-EDUC
ac6ce0ss4@educ
https://www.online-python.com/
https://luizpedroprofessor.blogspot.com/p/python.html

Variavel = valor que pode ser modificado ao longo do algoritmo
Constante = valor que é criado e fixado duranto todo o algoritmo

Tipos de dados
	caracter = texto entre aspas
 	inteiro = negativos e positivos
  	real = numero que tem pontuação
   	lógico = verdadeiro e falso

print() = printa dados
input() = recebe dados

Operadores Matemáticos
	+ adição
	- subtração
	* multiplicação
	/ divisão
	** exponenciação

Operadores Relacionais
	== igual
 	!= diferente
  	> maior
   	>= maior ou igual
    	< menor
	<= menor ou igual
 
Operadores Lógicos
	e = and
 	ou = or
  	não = not

Tabela Verdade
	AND
 		T and T = T
   		T and F = F
     		F and T = F
       		F and F = F
	OR
 		T or T = T
   		T or F = T
     		F or T = T
       		F or F = F
   	NOT
 		not T = F
   		not F = T

3º Aula - 24/07/2024 ###########################################################################################################

PYTHON
	linguagem de alto nivel
 	orientada a objetos
  	tipagem dinânima e forte
   	fácil aprendizagem
    	comunidade ativa
     	muitas bibliotecas/recursos
      	linguagem interpretada
