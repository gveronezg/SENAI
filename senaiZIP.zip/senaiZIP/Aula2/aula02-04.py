# 1. Solicite ao usuário que digite seu nome e imprima uma saudação com esse nome. (Fulano, Seja Bem Vindo)

nome = input('Entre com seu nome: ')
print('{}, Seja Bem Vindo!'.format(nome))

# 2. Peça ao usuário para digitar um número e imprima o dobro desse número.
