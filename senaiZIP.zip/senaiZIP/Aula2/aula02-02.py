a = 5
b = 8
c = 1

print(f'A = B AND B > C : {a == b and b > c}')
print(f'A <> B OR B < C : {a != b or b < c}')
print(f'NOT A > B : {not a > b}')
print(f'A < B AND B > C : {a < b and b > c}')
print(f'A >= B OR B = C : {a >= b or b == c}')
print(f'NOT A <= B : {not a <= b}')
