a = 5
b = 3

print(f'A = B : {a == b}') # False
print(f'A <> B : {a != b}') # True
print(f'A > B : {a > b}') # True
print(f'A < B : {a < b}') # False
print(f'A >= B : {a >= b}') # True
print(f'A <= B : {a <= b}') # False
