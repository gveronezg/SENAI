# Peça ao usuario para digitar um numero e imprima o dobro deste numero
# comando para entrada de dados
n = int(input("Digite um numero para dobrar: "))
# comando para saida de dados, informa a variavel digitada e seu dobro
print("O dobro de {} é: {}".format(n,(n*2)))

# Solicite duas strings do usuario e imprima a concatenação delas
txt1 = str(input("Entre com a string inicial: "))
txt2 = str(input("Agora entre com a string final: "))
print("Concatenando...")
print(txt1+" "+txt2)