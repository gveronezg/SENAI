"""
Frase na Tela - Implemente um programa que escreve na tela a frase "O primeiro programa a gente nunca esquece!
"""

print("O primeiro programa a gente nunca esquece!")