soma = (2+3)
print(f"A soma de 2 e 3 é: {soma}")