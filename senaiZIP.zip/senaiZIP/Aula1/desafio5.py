"""
Ao site - Faça um programa que mostre na tela o que você deseja fazer usando seus conhecimentos de Python.
"""