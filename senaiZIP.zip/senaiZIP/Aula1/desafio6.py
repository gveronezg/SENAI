"""
Quadrado - Escrever um programa que mostre a seguinte figura:
"""

x = "XXXXXX"
y = "X    X"

print(f"{x}\n{y}\n{y}\n{y}\n{x}")
