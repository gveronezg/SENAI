"""
Mensagem - Escreva uma mensagem para uma pessoa de quem goste. Implemente um programa que imprima essa mensagem, tire um print e mande pra essa pessoa.
Diga que foi um vírus que algum hacker instalou em seu computador.
"""
