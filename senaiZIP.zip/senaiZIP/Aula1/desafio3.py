"""
Letra de música - Faça um programa que mostre na tela uma letra de música que você gosta (proibido letras do Justin Bieber).
"""

letra_da_musica = "Todos os dias quando acordo\nNão tenho mais\nO tempo que passou\nMas tenho muito tempo\nTemos todo o tempo do mundo\nTodos os dias\nAntes de dormir\nLembro e esqueço\nComo foi o dia\nSempre em frente\nNão temos tempo a perder\nNosso suor sagrado\nÉ bem mais belo\nQue esse sangue amargo\nE tão sério\nE selvagem! Selvagem!\nSelvagem!\nVeja o sol\nDessa manhã tão cinza\nA tempestade que chega\nÉ da cor dos teus olhos\nCastanhos\nEntão me abraça forte\nE diz mais uma vez\nQue já estamos\nDistantes de tudo\nTemos nosso próprio tempo\nTemos nosso próprio tempo\nTemos nosso próprio tempo\nNão tenho medo do escuro\nMas deixe as luzes\nAcesas agora\nO que foi escondido\nÉ o que se escondeu\nE o que foi prometido\nNinguém prometeu\nNem foi tempo perdido\nSomos tão jovens\nTão jovens! Tão jovens!"

print(letra_da_musica)