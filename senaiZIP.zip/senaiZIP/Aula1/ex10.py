print("Aprendendo Python...")
print("Aprendendo Python...")
print("Aprendendo Python...")