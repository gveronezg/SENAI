negativo = -10
print(negativo)