"""
Etiqueta - Elabore um programa que escreve seu nome completo na primeira linha, seu endereço na segunda, e o CEP e telefone na terceira.
"""

nome = "Gabriel"
endereço = "Bernardes Pinto"
cep_telefone = "14409242 ; 16991941010"

print(f'{nome}\n{endereço}\n{cep_telefone}')